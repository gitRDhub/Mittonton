﻿using UnityEngine;
using System.Collections;

public class Tile : MonoBehaviour {

  public int value;
  public int power;
  public bool upgradedThisTurn;
  
}
